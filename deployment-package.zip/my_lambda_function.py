import json
import boto3

def lambda_handler(event, context):
    try:
        # Extract 'text' from the incoming request body
        request_body = json.loads(event['body'])
        text = request_body.get('text')

        # Check if 'text' is present in the request
        if text is None:
            raise ValueError("Missing 'text' field in the request body")

        # Specify the language code (e.g., 'en' for English)
        language_code = 'en'

        # Call AWS Comprehend service to perform sentiment analysis
        comprehend = boto3.client('comprehend', region_name='ap-southeast-2')
        response = comprehend.detect_sentiment(Text=text, LanguageCode=language_code)

        # Process the response as needed
        # ...

        # Return a successful response
        return {
            'statusCode': 200,
            'body': json.dumps(response)
        }

    except Exception as e:
        # Handle any errors and return an error response
        return {
            'statusCode': 400,
            'body': json.dumps({
                '__type': 'ValidationException',
                'message': str(e)
            })
        }
